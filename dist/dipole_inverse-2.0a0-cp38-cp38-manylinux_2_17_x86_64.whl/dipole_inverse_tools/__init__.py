from .tools import set_max_num_threads
